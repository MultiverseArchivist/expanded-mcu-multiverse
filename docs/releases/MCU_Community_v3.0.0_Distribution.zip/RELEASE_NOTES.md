# Expanded MCU Multiverse Community Edition v3.0.0

The initial public release tracks 965 entries in original public release order, with **730 Main**, **113 Optional**, and **122 Documentaries & Extras** entries. Track progress and ratings, find your next entry in Marathon Hub, see progress by franchise or continuity, and browse upcoming releases and supplemental reminders.

A local Python upgrade utility carries supported personal progress to a future workbook by permanent content ID. See the upgrade guide for supported fields and instructions.

Tested in LibreOffice Calc. Distributed in XLSX format. The maintainer opened and recalculated a browser-migrated workbook in desktop Microsoft Excel. Support across all Excel features and versions remains unverified. Some historical dates, runtimes, and access links remain uncertain and are qualified in the workbook.

Dashboard maintenance: Restored spacer styling and repaired the active-entry series and episode lookups.

Acceptance maintenance: Dashboard opens at A1. Upgrades keep the target workbook’s opening positions and show clearer recovery guidance.
