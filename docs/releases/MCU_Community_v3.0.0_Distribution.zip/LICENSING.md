# Community Edition distribution licensing

© 2026 The Multiverse Archivist

| Material in this ZIP | License |
| --- | --- |
| Original, licensable contributions to the Community Edition XLSX and original text in README.md, RELEASE_NOTES.md, UPGRADE.md, and this notice | [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International](licenses/CC-BY-NC-SA-4.0.txt) |
| Original code in `migrate_progress.py` | [MIT License](licenses/MIT.txt) |

The website and browser migration code are also MIT licensed. Third-party material and dependencies retain their existing rights and licenses. See the [project repository](https://github.com/MultiverseArchivist/expanded-mcu-multiverse) for the source and dependency notices.

## Attribution

For Creative Commons material, credit **Expanded MCU Multiverse, Community Edition v3.0.0**, by **The Multiverse Archivist**. Include the [project website](https://multiversearchivist.github.io/expanded-mcu-multiverse/), a [link to the CC BY-NC-SA 4.0 license](https://creativecommons.org/licenses/by-nc-sa/4.0/), and an indication of any changes. Keep the copyright and permission notice with copies or substantial portions of the MIT-licensed code.

## Third-party material

The project licenses cover only original material for which The Multiverse Archivist can grant permission. Marvel, Disney, ABC, and other third parties retain their rights in names, trademarks, characters, logos, artwork, films, television, comics, quoted text, and other third-party material. Catalog references and links grant no rights in material they identify. The project licenses place no conditions on the independent use of unprotected facts.
